﻿using JulMar.Windows.Services;

namespace SampleBoxes
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    [ExportPage("BoxDetailsPage", typeof(BoxDetailsPage))]
    public sealed partial class BoxDetailsPage
    {
        public BoxDetailsPage()
        {
            this.InitializeComponent();
        }
    }
}
