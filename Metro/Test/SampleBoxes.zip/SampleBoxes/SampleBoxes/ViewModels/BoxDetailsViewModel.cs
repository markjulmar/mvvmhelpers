﻿using JulMar.Windows.Interfaces;
using JulMar.Windows.Mvvm;
using System.Composition;
using JulMar.Windows.Services;

namespace SampleBoxes.ViewModels
{
    [ExportViewModel("BoxDetailsVM")]
    public sealed class BoxDetailsViewModel : ViewModel//, INavigationAware
    {
        private string _color;

        [ViewModelState]
        public string Color
        {
            get { return _color; }
            set { SetPropertyValue(ref _color, value); }
        }

        [Import]
        public IPageNavigator PageNavigator { get; set; }
        public IDelegateCommand GoBack { get; private set; }

        public BoxDetailsViewModel()
        {
            GoBack = new DelegateCommand(() => PageNavigator.GoBack(), () => PageNavigator.CanGoBack);
        }

        // Alternative to the attributed approach is to save it via the INavigationAware
        // interface
        //public void OnNavigatedTo(NavigatedToEventArgs e)
        //{
        //    if (e.State != null)
        //    {
        //        if (e.State.ContainsKey("Color"))
        //            Color = (string) e.State["Color"];
        //    }
        //}

        //public void OnNavigatingFrom(NavigatingFromEventArgs e)
        //{
        //    if (e.State != null)
        //    {
        //        e.State["Color"] = Color;
        //    }
        //}
    }
}
