using Windows.UI;

namespace SampleBoxes.ViewModels
{
    public sealed class ColorBox
    {
        public string Color { get; private set; }

        public ColorBox(Color color)
        {
            Color = color.ToString();
        }
    }
}