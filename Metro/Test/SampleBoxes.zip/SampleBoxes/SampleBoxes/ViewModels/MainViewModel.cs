﻿using System;
using System.Collections.ObjectModel;
using System.Linq;
using JulMar.Windows.Interfaces;
using JulMar.Windows.Mvvm;
using System.Collections.Generic;
using System.Composition;
using Windows.UI;
using Windows.UI.Xaml.Controls;

namespace SampleBoxes.ViewModels
{
    [ExportViewModel("MainViewModel")]
    public sealed class MainViewModel : ViewModel
    {
        static Random RNG = new Random();

        public IList<ColorBox> Boxes { get; private set; }

        [Import]
        public IPageNavigator PageNavigator { get; set; }
        public IDelegateCommand ShowDetails { get; private set; }

        public MainViewModel()
        {
            Boxes = new ObservableCollection<ColorBox>(
                Enumerable.Range(0, 200).Select(n => new ColorBox(
                    Color.FromArgb(255, (byte)RNG.Next(255), (byte)RNG.Next(255), (byte)RNG.Next(255)))));

            ShowDetails = new DelegateCommand<ItemClickEventArgs>(OnShowDetails);
        }

        private void OnShowDetails(ItemClickEventArgs e)
        {
            ColorBox box = (ColorBox) e.ClickedItem;
            PageNavigator.NavigateTo("BoxDetailsPage", box.Color, new BoxDetailsViewModel() { Color = box.Color });
        }
    }
}
