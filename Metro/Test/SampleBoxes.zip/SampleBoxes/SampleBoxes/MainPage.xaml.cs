﻿using JulMar.Windows.Services;

namespace SampleBoxes
{
    [ExportPage("MainPage", typeof(MainPage))]
    public sealed partial class MainPage
    {
        public MainPage()
        {
            this.InitializeComponent();
        }
    }
}
